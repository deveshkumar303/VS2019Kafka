﻿using Kafka_Producer.Modules;
using System;

namespace Kafka_Producer
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Kafka Producer!");
            Console.WriteLine("Enter your message. Enter X for quitting");
            var message = default(string);
            while ((message = Console.ReadLine()) != "X")
            {
                var producer = new KafkaProducer();
                producer.Produce(message);
            }
        }

        private void readMQ()
        { Console.WriteLine("Enter your message. Enter X for quitting"); }
    }
}
