﻿using System;
using System.Collections.Generic;
using System.Text;
using Confluent.Kafka;
using Confluent.Kafka.Serialization;
using Kafka_Producer.Interface;
namespace Kafka_Producer.Modules
{
    public class KafkaProducer : IKafkaProducer
    {
        public void Produce(string message)
        {
            var config = new Dictionary<string, object>
            {
                { "bootstrap.servers", "localhost:9092"}
            };
            using (var producer = new Producer<Null, string>(config, null, new StringSerializer(Encoding.UTF8)))
            {
                producer.ProduceAsync("kafka_topic", null, message).GetAwaiter().GetResult();
                producer.Flush(100); //Wait time for flush 100 ms
            }
        }
    }
}
