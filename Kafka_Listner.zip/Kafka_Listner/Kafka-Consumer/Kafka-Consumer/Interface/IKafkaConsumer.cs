﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kafka_Consumer.Interface
{
    public interface IKafkaConsumer
    {
        void Listen(Action<string> message);
    }
}
