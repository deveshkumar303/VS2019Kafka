﻿using System;
using System.Collections.Generic;
using System.Text;
using Confluent.Kafka;
using Confluent.Kafka.Serialization;
using Kafka_Consumer.Interface;

namespace Kafka_Consumer.Modules
{

    public class kafkaConsumer : IKafkaConsumer
    {
        public void Listen(Action<string> message)
        {
            var config = new Dictionary<string, object>
        {
            {"group.id","kafka_consumer" },
            {"bootstrap.servers", "localhost:9092" },
                { "auto.offset.reset", "earliest"}
                //{ "auto.offset.reset", "smallest"}
                //{ "auto.offset.reset", "latest"}
        };

            using (var consumer = new Consumer<Null, string>(config, null, new StringDeserializer(Encoding.UTF8)))
            {
                consumer.Subscribe("kafka_topic");
                consumer.OnMessage += (_, msg) =>
                {
                    message(msg.Value);
                };

                while (true)
                {
                    consumer.Poll(100); //wait for 100 ms
                }
            }
        }
    }
}

