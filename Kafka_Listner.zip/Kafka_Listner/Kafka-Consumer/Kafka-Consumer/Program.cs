﻿using System;
using Kafka_Consumer.Modules;
namespace Kafka_Consumer
{
    class Program
    {
        static void Main(string[] args)
        {
            var kafkaConsumer = new kafkaConsumer();
            kafkaConsumer.Listen(Console.WriteLine);
            //Console.WriteLine("Hello World!");
        }
    }
}
